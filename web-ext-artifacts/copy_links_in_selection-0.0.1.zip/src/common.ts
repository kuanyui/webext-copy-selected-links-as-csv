
export interface TypedMsg {
    type: 'copySelectedLinks'
}
